# Java application with H2 database + Hibernate annotation mapping

The application describes work with: H2 database, Hibernate annotation mapping

## Database structure

![full_db_schema](https://cloud.githubusercontent.com/assets/5372875/22624532/4cbef472-eb87-11e6-98eb-7a35541d2a49.jpg)

The application describes @OneToOne and @ManyToMany
